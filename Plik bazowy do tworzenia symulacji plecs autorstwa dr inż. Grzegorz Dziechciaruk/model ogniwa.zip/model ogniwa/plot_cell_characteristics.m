close all
clear all

%% run the script with cell parameters:

cell_parameters_plecs
% see the file for loaded parameters 

%% plot approximation functions

% prepare characteristic arrays
dod_rel = [ 0: 0.01 : 1 ];

Rs_char = Rs_ref * ones( size( dod_rel ) );
R1_char = R1_ref * functionExpAndLinear( dod_rel, R1_aprox_param );
R2_char = R2_ref * functionExpAndLinear( dod_rel, R2_aprox_param );

tau1_char = tau1_ref * ones( size(dod_rel) );
tau2_char = tau2_ref * ones( size(dod_rel) );

OCV_char = OCV_aprox( dod_rel, OCV_aprox_param );

% plot Resistance chcaracteristics
figure
plot(dod_rel, Rs_char)
hold on;
plot(dod_rel, R1_char);
plot(dod_rel, R2_char);
legend('R_s','R_1','R_2');
ylabel('R [\Omega]');
xlabel('stan rozladowania, q^*_d [p.u]');
grid on; 

% plot time constant chcaracteristics
figure
plot(dod_rel, tau1_char);
hold on;
plot(dod_rel, tau2_char);
ylim([0 800])
legend('\tau_1','\tau_2','Location','best');
ylabel('time constants [s]');
xlabel('stan rozladowania, q^*_d [p.u]');
grid on; 

% plot OCV characteristic
figure
plot( dod_rel, OCV_char );
ylabel('U_{OCV} [V]');
grid on; 
xlabel('stan rozladowania, q^*_d [p.u]');

%% used functions

function [y] = functionExpAndLinear(x,parameters)

a = parameters(1);
b = parameters(2);
c = parameters(3);
d = parameters(4);
e = parameters(5);

y =  a*exp(b*x-c)+ d + e*x;

end

function Uocv = OCV_aprox(qd, parameters)
    a0 = parameters(1);
    a1 = parameters(2);
    a2 = parameters(3);
    a3 = parameters(4);
    a4 = parameters(5);
    a5 = parameters(6);
    a6 = parameters(7);
 
    Uocv = a0*exp(a1*(qd+a6))+ a2 + a3*qd + a4*qd.^2 + a5*qd.^3;
end